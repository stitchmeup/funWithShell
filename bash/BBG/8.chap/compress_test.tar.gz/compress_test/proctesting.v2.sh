#!/bin/bash

while true; do echo "Find me!"; sleep 2; done
